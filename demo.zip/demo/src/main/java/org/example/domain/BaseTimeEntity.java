package org.example.domain;

public class BaseTimeEntity {
}
